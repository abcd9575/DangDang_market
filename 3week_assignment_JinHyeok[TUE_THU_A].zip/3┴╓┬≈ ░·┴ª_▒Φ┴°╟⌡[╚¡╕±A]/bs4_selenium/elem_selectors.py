INPUT_SEARCH_SELECTOR = "input[id=headerSearchKeyword"
PROD_LIST_SELECTOR = "ul#productList"
PROD_ITEM_SELECTOR = "li.search-product"